python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_96 \
  --model Crossformer \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 96 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --top_k 5 \
  --des 'Exp' \
  --d_model 512 \
  --d_ff 2048 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type1 \
  --train_epochs 10 \
  --batch_size 8
  
mse:0.4258572459220886, mae:0.27891799807548523


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_192 \
  --model Crossformer \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 96 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --top_k 5 \
  --des 'Exp' \
  --d_model 512 \
  --d_ff 2048 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type1 \
  --train_epochs 10 \
  --batch_size 2
mse:0.43848904967308044, mae:0.27195045351982117



python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_336 \
  --model Crossformer \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 96 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --top_k 5 \
  --des 'Exp' \
  --d_model 512 \
  --d_ff 2048 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type1 \
  --train_epochs 10 \
  --batch_size 2
mse:0.4948272407054901, mae:0.2900431156158447

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_720 \
  --model Crossformer \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 96 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --top_k 5 \
  --des 'Exp' \
  --d_model 256 \
  --d_ff 512 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type1 \
  --train_epochs 10 \
  --batch_size 2

mse:0.5023748278617859, mae:0.3082936406135559
