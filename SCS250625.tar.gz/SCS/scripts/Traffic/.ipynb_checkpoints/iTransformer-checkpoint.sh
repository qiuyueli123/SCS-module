#export CUDA_VISIBLE_DEVICES=2

#model_name=iTransformer



python -u run.py \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_96 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 4 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --des 'Exp' \
  --d_model 480\
  --d_ff 480 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --train_epochs 20 \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.001 \
  --lradj type3 \
  --coef_resnet 0
mse:0.39065036177635193, mae:0.27174708247184753



python -u run.py \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_192 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 4 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --des 'Exp' \
  --d_model 560\
  --d_ff 560 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --train_epochs 20 \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.001 \
  --lradj type3 \
  --coef_resnet 0
  
mse:0.4153045117855072, mae:0.2803609371185303  
  

python -u run.py \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_336 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 4 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --des 'Exp' \
  --d_model 720\
  --d_ff 720 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --train_epochs 20 \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.001 \
  --lradj type3 \
  --coef_resnet 0
mse:0.4443416893482208, mae:0.2906630039215088  
  


  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_720 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --pred_len 720 \
  --e_layers 4 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --des 'Exp' \
  --d_model 512\
  --d_ff 512 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --train_epochs 12 \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.00025 \
  --lradj type3 \
  --coef_resnet 0
  
mse:0.46731922030448914, mae:0.313884437084198  
  
  







