python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_96 \
  --model PatchTST \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --d_model 512 \
  --d_ff 512 \
  --top_k 5 \
  --des 'Exp' \
  --batch_size 4 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --train_epochs 5 \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type3


mse:0.450164914131164   mae:0.298785477876663
  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_192 \
  --model PatchTST \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --d_model 512 \
  --d_ff 512 \
  --top_k 5 \
  --des 'Exp' \
  --batch_size 4 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --train_epochs 5 \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type3
  
mse:0.45423024892807  mas:0.303798288106918


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_336 \
  --model PatchTST \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --d_model 512 \
  --d_ff 512 \
  --top_k 5 \
  --des 'Exp' \
  --batch_size 4 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --train_epochs 5 \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type3
  
  
mse:0.478281617164611  mae:0.312104076147079

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_720 \
  --model PatchTST \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --d_model 512 \
  --d_ff 512 \
  --top_k 5 \
  --des 'Exp' \
  --batch_size 4 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --train_epochs 5 \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type3

mse:0.516295790672302  mae:0.3271065056324