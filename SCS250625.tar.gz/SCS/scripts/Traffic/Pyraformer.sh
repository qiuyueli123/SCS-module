export CUDA_VISIBLE_DEVICES=6

model_name=Pyraformer

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_96 \
  --model 'Pyraformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --des 'Exp' \
  --des 'Exp' \
  --d_model 512\
  --d_ff 512 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --train_epochs 20 \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.001 \
  --lradj type3
  
mse:0.5952397584915161, mae:0.3192433714866638
  




python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_192 \
  --model 'Pyraformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --des 'Exp' \
  --des 'Exp' \
  --d_model 512\
  --d_ff 512 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --train_epochs 20 \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.001 \
  --lradj type3
mse:0.6169561147689819, mae:0.32989805936813354





python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_336 \
  --model 'Pyraformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --des 'Exp' \
  --des 'Exp' \
  --d_model 512\
  --d_ff 512 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --train_epochs 20 \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.001 \
  --lradj type3
  
mse:0.6297879815101624, mae:0.33521467447280884



python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/traffic/ \
  --data_path traffic.csv \
  --model_id traffic_96_720 \
  --model 'Pyraformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 862 \
  --dec_in 862 \
  --c_out 862 \
  --des 'Exp' \
  --des 'Exp' \
  --d_model 256\
  --d_ff 256 \
  --itr 1 \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --train_epochs 10 \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.001 \
  --lradj type3
  
mse:0.6623901724815369, mae:0.3539806306362152