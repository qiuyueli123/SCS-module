export CUDA_VISIBLE_DEVICES=0

model_name=iTransformer
  
  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/electricity/ \
  --data_path electricity.csv \
  --model_id ECL_96_96 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --pred_len 96 \
  --e_layers 3 \
  --enc_in 321 \
  --dec_in 321 \
  --c_out 321 \
  --des 'Exp' \
  --d_model 1024 \
  --d_ff 1024 \
  --batch_size 12 \
  --learning_rate 0.0005 \
  --lradj 'type3' \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --trans_data True \
  --kernel_size 3 \
  --itr 1 \
  --embed_dropout 0.1 \
  --coef_resnet 1
    
mse:0.13531993329524994, mae:0.23239485919475555
  

python -u run.py \
  --is_training 1 \
  --root_path ./dataset/electricity/ \
  --data_path electricity.csv \
  --model_id ECL_96_192 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --pred_len 192 \
  --e_layers 3 \
  --enc_in 321 \
  --dec_in 321 \
  --c_out 321 \
  --des 'Exp' \
  --d_model 1024 \
  --d_ff 1024 \
  --batch_size 12 \
  --learning_rate 0.0005 \
  --lradj 'type3' \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --trans_data True \
  --kernel_size 3 \
  --itr 1 \
  --embed_dropout 0.1 \
  --coef_resnet 1
    
mse:0.15566803514957428, mae:0.2518351376056671  
  

  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/electricity/ \
  --data_path electricity.csv \
  --model_id ECL_96_336 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --pred_len 336 \
  --e_layers 3 \
  --enc_in 321 \
  --dec_in 321 \
  --c_out 321 \
  --des 'Exp' \
  --d_model 1024 \
  --d_ff 1024 \
  --batch_size 12 \
  --learning_rate 0.0005 \
  --lradj 'type3' \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --trans_data True \
  --kernel_size 3 \
  --itr 1 \
  --embed_dropout 0.1 \
  --coef_resnet 1  
  
mse:0.17280928790569305, mae:0.2680889368057251  
  
  
  
  python -u run.py \
  --is_training 1 \
  --root_path ./dataset/electricity/ \
  --data_path electricity.csv \
  --model_id ECL_96_720 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --pred_len 720 \
  --e_layers 1 \
  --enc_in 321 \
  --dec_in 321 \
  --c_out 321 \
  --des 'Exp' \
  --d_model 4096 \
  --d_ff 4096 \
  --batch_size 12 \
  --learning_rate 0.0005 \
  --lradj 'type3' \
  --date_index 'HourOfDay' 'DayOfWeek' \
  --trans_data True \
  --kernel_size 3 \
  --itr 1 \
  --embed_dropout 0.1 \
  --coef_resnet 1  
  
mse:0.21161571145057678, mae:0.29971516132354736  
  
  

  
  
  
  