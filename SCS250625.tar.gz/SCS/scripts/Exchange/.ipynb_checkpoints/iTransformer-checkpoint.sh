export CUDA_VISIBLE_DEVICES=3

model_name=iTransformer


python -u run.py \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_96 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --pred_len 96 \
  --e_layers 8 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --d_model 8 \
  --d_ff 24 \
  --itr 1 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.0015 \
  --lradj type1 \
  --train_epochs 3 \
  --embed_dropout 0.1 \
  --coef_resnet 1
  
mse:0.08347976952791214, mae:0.20319122076034546  
  
  
  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_192 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --pred_len 192 \
  --e_layers 8 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --d_model 12 \
  --d_ff 24 \
  --itr 1 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.0015 \
  --lradj type1 \
  --train_epochs 2 \
  --embed_dropout 0.2 \
  --coef_resnet 1
  
mse:0.17212533950805664, mae:0.2964787781238556  

  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_336 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --pred_len 336 \
  --e_layers 8 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --d_model 8 \
  --d_ff 24 \
  --itr 1 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.0015 \
  --lradj type1 \
  --train_epochs 3 \
  --embed_dropout 0.1 \
  --coef_resnet 0.1
  
 mse:0.3255048096179962, mae:0.4135403037071228 
  




python -u run.py \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_720 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --pred_len 720 \
  --e_layers 8 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --d_model 8 \
  --d_ff 24 \
  --itr 1 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.0015 \
  --lradj type1 \
  --train_epochs 3 \
  --embed_dropout 0.1 \
  --coef_resnet 1
  
mse:0.8133600354194641, mae:0.6801761984825134