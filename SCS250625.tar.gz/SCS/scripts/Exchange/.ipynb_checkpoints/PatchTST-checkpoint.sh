export CUDA_VISIBLE_DEVICES=5

model_name=PatchTST

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_96 \
  --model 'PatchTST' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --itr 1 \
  --d_model 512 \
  --d_ff 2048 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.001 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.08582349121570587, mae:0.20403721928596497 
  


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_192 \
  --model 'PatchTST' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --itr 1 \
  --d_model 2048 \
  --d_ff 2048 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.001 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.16390134394168854, mae:0.2904685139656067  

  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_336 \
  --model 'PatchTST' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --itr 1 \
  --d_model 512 \
  --d_ff 512 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0025 \
  --lradj type3 \
  --train_epochs 1
  
mse:0.29691147804260254, mae:0.3987782895565033  
  
  

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_720 \
  --model 'PatchTST' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --itr 1 \
  --d_model 1024 \
  --d_ff 1024 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.002 \
  --lradj type3 \
  --train_epochs 1
  
mse:0.8926922082901001, mae:0.7157026529312134