export CUDA_VISIBLE_DEVICES=4

model_name=Crossformer

  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_96 \
  --model 'Crossformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 96 \
  --pred_len 96 \
  --e_layers 8 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --d_model 128 \
  --d_ff 128 \
  --top_k 5 \
  --des 'Exp' \
  --itr 1 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type1 \
  --train_epochs 1
  

mse:0.12192831188440323, mae:0.2535679340362549

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_192 \
  --model 'Crossformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 96 \
  --pred_len 192 \
  --e_layers 8 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --d_model 128 \
  --d_ff 128 \
  --top_k 5 \
  --des 'Exp' \
  --itr 1 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type1 \
  --train_epochs 10
  

mse:0.2063741236925125, mae:0.3332797884941101


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_336 \
  --model 'Crossformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 96 \
  --pred_len 336 \
  --e_layers 8 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --d_model 128 \
  --d_ff 128 \
  --top_k 5 \
  --des 'Exp' \
  --itr 1 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.00002 \
  --lradj type1 \
  --train_epochs 3
  
mse:0.32969456911087036, mae:0.4194134473800659  
  
  


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_720 \
  --model 'Crossformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 96 \
  --pred_len 720 \
  --e_layers 8 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --d_model 128 \
  --d_ff 128 \
  --top_k 5 \
  --des 'Exp' \
  --itr 1 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type1 \
  --train_epochs 1
  
mse:0.9452677965164185, mae:0.7475502490997314