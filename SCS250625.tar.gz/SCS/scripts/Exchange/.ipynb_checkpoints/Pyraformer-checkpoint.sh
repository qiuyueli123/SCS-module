export CUDA_VISIBLE_DEVICES=4

model_name=Pyraformer

  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_96 \
  --model 'Pyraformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --itr 1 \
  --d_model 1024 \
  --d_ff 1024 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.001 \
  --lradj type3 \
  --train_epochs 1
  
 mse:0.13543105125427246, mae:0.267947793006897 


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_192 \
  --model 'Pyraformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --itr 1 \
  --d_model 1024 \
  --d_ff 1024 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.001 \
  --lradj type3 \
  --train_epochs 1
  
 mse:0.24561938643455505, mae:0.361607909202575 
  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_336 \
  --model 'Pyraformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --itr 1 \
  --d_model 1024 \
  --d_ff 1024 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.001 \
  --lradj type3 \
  --train_epochs 1
  
mse:0.4431542158126831, mae:0.4942077100276947


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_720 \
  --model 'Pyraformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --itr 1 \
  --d_model 1024 \
  --d_ff 1024 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.001 \
  --lradj type3 \
  --train_epochs 1
  
 
mse:1.0177083015441895, mae:0.7731021642684937