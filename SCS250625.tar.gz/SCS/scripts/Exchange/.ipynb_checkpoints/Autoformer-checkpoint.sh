export CUDA_VISIBLE_DEVICES=7

model_name=Autoformer


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_96 \
  --model 'Autoformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 3 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --itr 1 \
  --d_model 512 \
  --d_ff 512 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type3 \
  --train_epochs 1
  
mse:0.14090949296951294, mae:0.27573361992836  
  

  
  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_192 \
  --model 'Autoformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --itr 1 \
  --d_model 512 \
  --d_ff 512 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.2928183376789093, mae:0.39754804968833923


  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_336 \
  --model 'Autoformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --itr 1 \
  --d_model 512 \
  --d_ff 512 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0001 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.44975247979164124, mae:0.4955393075942993


  
  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/exchange_rate/ \
  --data_path exchange_rate.csv \
  --model_id Exchange_96_336 \
  --model 'Autoformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 8 \
  --dec_in 8 \
  --c_out 8 \
  --des 'Exp' \
  --itr 1 \
  --d_model 512 \
  --d_ff 512 \
  --date_index 'MonthOfYear' \
  --trans_data True \
  --kernel_size 1 \
  --learning_rate 0.0002 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.6128666996955872, mae:0.5807694792747498