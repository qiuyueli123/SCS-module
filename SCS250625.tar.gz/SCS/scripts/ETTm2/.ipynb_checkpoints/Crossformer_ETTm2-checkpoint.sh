export CUDA_VISIBLE_DEVICES=4

model_name=Crossformer

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm2.csv \
  --model_id ETTm2_96_96 \
  --model 'Crossformer' \
  --data ETTm2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 512 \
  --d_ff 2048 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.00001 \
  --lradj type1 \
  --kernel_size 3 
mse:0.18075646460056305, mae:0.26608261466026306




python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm2.csv \
  --model_id ETTm2_96_192 \
  --model 'Crossformer' \
  --data ETTm2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 512 \
  --d_ff 2048 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.00001 \
  --lradj type1 \
  --kernel_size 3 

mse:0.24962015450000763, mae:0.3078387379646301  
  
  
  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm2.csv \
  --model_id ETTm2_96_336 \
  --model 'Crossformer' \
  --data ETTm2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 512 \
  --d_ff 2048 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.0001 \
  --lradj type1 \
  --kernel_size 3 
  
mse:0.30790945887565613, mae:0.3449367582798004
  
  

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm2.csv \
  --model_id ETTm2_96_720 \
  --model 'Crossformer' \
  --data ETTm2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 512 \
  --d_ff 2048 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.001 \
  --lradj type1 \
  --kernel_size 3   
  
mse:0.4170709550380707, mae:0.41289225220680237
