export CUDA_VISIBLE_DEVICES=0

model_name=iTransformer

python -u run.py \

  
  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm2.csv \
  --model_id ETTm2_96_96 \
  --model 'iTransformer' \
  --data ETTm2 \
  --features M \
  --seq_len 96 \
  --pred_len 96 \
  --e_layers 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 1024 \
  --d_ff 1024 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --learning_rate 0.001 \
  --itr 1 \
  --train_epochs 10 \
  --patience 3 \
  --kernel_size 3 \
  --lradj type1 \
  --embed_dropout 0 \
  --coef_resnet 1
  
mse:0.16931623220443726, mae:0.25274863839149475  
  
  
  
  
  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm2.csv \
  --model_id ETTm2_96_192 \
  --model 'iTransformer' \
  --data ETTm2 \
  --features M \
  --seq_len 96 \
  --pred_len 192 \
  --e_layers 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 1024 \
  --d_ff 1024 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --learning_rate 0.001 \
  --itr 1 \
  --train_epochs 10 \
  --patience 3 \
  --kernel_size 3 \
  --lradj type1 \
  --embed_dropout 0 \
  --coef_resnet 1
    
mse:0.23625072836875916, mae:0.29688411951065063  
  
  
  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm2.csv \
  --model_id ETTm2_96_336 \
  --model 'iTransformer' \
  --data ETTm2 \
  --features M \
  --seq_len 96 \
  --pred_len 336 \
  --e_layers 4 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 96 \
  --d_ff 96 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --learning_rate 0.001 \
  --itr 1 \
  --train_epochs 10 \
  --patience 3 \
  --kernel_size 3 \
  --lradj type1 \
  --embed_dropout 0 \
  --coef_resnet 1
  
mse:0.296773225069046, mae:0.333509624004364  
  


  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm2.csv \
  --model_id ETTm2_96_720 \
  --model 'iTransformer' \
  --data ETTm2 \
  --features M \
  --seq_len 96 \
  --pred_len 720 \
  --e_layers 4 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 96 \
  --d_ff 96 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --learning_rate 0.001 \
  --itr 1 \
  --train_epochs 10 \
  --patience 3 \
  --kernel_size 3 \
  --lradj type1 \
  --embed_dropout 0 \
  --coef_resnet 1
  
 mse:0.3975299596786499, mae:0.3920785188674927 
  
  