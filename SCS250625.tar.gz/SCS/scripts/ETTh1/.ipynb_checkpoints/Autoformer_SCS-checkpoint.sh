model_name=Autoformer



python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_96 \
  --model 'Autoformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --n_heads 2 \
  --itr 1 \
  --trans_data True \
  --kernel_size 3 \
  --d_model 512 \
  --d_ff 2048 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.4065975844860077, mae:0.4344310462474823

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_192 \
  --model 'Autoformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 3 \
  --d_model 512 \
  --d_ff 2048 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --lradj type3 \
  --train_epochs 10

mse:0.448149174451828, mae:0.46132394671440125
  
  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_336 \
  --model 'Autoformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 3 \
  --d_model 512 \
  --d_ff 512 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --lradj type3 \
  --train_epochs 10
mse:0.47624289989471436, mae:0.47433188557624817  
  

  

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_720 \
  --model 'Autoformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 3 \
  --d_model 1024 \
  --d_ff 2048 \
  --date_index 'HourOfDay' \
  --learning_rate 0.001 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.48842981457710266, mae:0.5028414726257324