
model_name=Crossformer



python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_96 \
  --model 'Crossformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 3 \
  --d_model 512 \
  --d_ff 1024 \
  --date_index 'HourOfDay' \
  --learning_rate 0.001 \
  --lradj type3 \
  --train_epochs 10
mse:0.38298317790031433, mae:0.4076721668243408




python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_192 \
  --model 'Crossformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 3 \
  --d_model 512 \
  --d_ff 1024 \
  --date_index 'HourOfDay' \
  --learning_rate 0.001 \
  --lradj type3 \
  --train_epochs 10

mse:0.4226037263870239, mae:0.4392150342464447


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_336 \
  --model 'Crossformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 3 \
  --d_model 512 \
  --d_ff 1024 \
  --date_index 'HourOfDay' \
  --learning_rate 0.001 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.4711418151855469, mae:0.4548761248588562  



  

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_720 \
  --model 'Crossformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 3 \
  --d_model 512 \
  --d_ff 1024 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.4790721535682678, mae:0.47746217250823975