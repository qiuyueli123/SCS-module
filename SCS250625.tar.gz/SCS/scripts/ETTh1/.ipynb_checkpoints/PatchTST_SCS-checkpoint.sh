model_name=PatchTST

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_96 \
  --model 'PatchTST' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 3 \
  --d_model 512 \
  --d_ff 2048 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --lradj type3 \
  --train_epochs 10

mse:0.3774421215057373, mae:0.4057125449180603

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_192 \
  --model 'PatchTST' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 3 \
  --d_model 512 \
  --d_ff 2048 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --lradj type3 \
  --train_epochs 10
mse:0.4188355505466461, mae:0.429304301738739  

  
  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_336 \
  --model 'PatchTST' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 1 \
  --d_model 1024 \
  --d_ff 2048 \
  --date_index 'HourOfDay' \
  --learning_rate 0.001 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.45667457580566406, mae:0.45081764459609985  
  
  
  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_720 \
  --model 'PatchTST' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 1 \
  --d_model 1024 \
  --d_ff 2048 \
  --date_index 'HourOfDay' \
  --learning_rate 0.001 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.4510648250579834, mae:0.4618605673313141  
