export CUDA_VISIBLE_DEVICES=0

model_name=Pyraformer

  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_96 \
  --model 'Pyraformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 1 \
  --d_model 256 \
  --d_ff 256 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.40209418535232544, mae:0.42384952306747437  
  
  
  

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_192 \
  --model 'Pyraformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 1 \
  --d_model 512 \
  --d_ff 512 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --lradj type3 \
  --train_epochs 10

mse:0.4449194371700287, mae:0.44734877347946167

 
  

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_336 \
  --model 'Pyraformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 1 \
  --d_model 512 \
  --d_ff 512 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --lradj type3 \
  --train_epochs 10

mse:0.49505630135536194, mae:0.4727739989757538



python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_720 \
  --model 'Pyraformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --kernel_size 1 \
  --d_model 512 \
  --d_ff 512 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --lradj type3 \
  --train_epochs 10

mse:0.49607953429222107, mae:0.4857785701751709



