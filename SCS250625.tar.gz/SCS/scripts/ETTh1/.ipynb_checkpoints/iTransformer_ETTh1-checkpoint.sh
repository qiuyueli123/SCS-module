export CUDA_VISIBLE_DEVICES=1

model_name=iTransformer


python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_96 \
  --model 'iTransformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --pred_len 96 \
  --e_layers 4 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 1024 \
  --d_ff 1024 \
  --itr 1 \
  --date_index  'HourOfDay'  \
  --learning_rate 0.001 \
  --trans_data True \
  --kernel_size 1 \
  --lradj type1 \
  --train_epochs 10 \
  --embed_dropout 0.1 \
  --coef_resnet 1
  
mse:0.37756475806236267, mae:0.3937654495239258  
  
  
  
 
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_192 \
  --model 'iTransformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --pred_len 192 \
  --e_layers 4 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 1024 \
  --d_ff 1024 \
  --itr 1 \
  --date_index  'HourOfDay'  \
  --learning_rate 0.001 \
  --trans_data True \
  --kernel_size 1 \
  --lradj type1 \
  --train_epochs 10 \
  --embed_dropout 0.1 \
  --coef_resnet 1 
  
  
mse:0.4280261695384979, mae:0.4212145507335663  
  
  
  
  
 
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_336 \
  --model 'iTransformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --pred_len 336 \
  --e_layers 4 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 1024 \
  --d_ff 1024 \
  --itr 1 \
  --date_index  'HourOfDay'  \
  --learning_rate 0.001 \
  --trans_data True \
  --kernel_size 1 \
  --lradj type1 \
  --train_epochs 10 \
  --embed_dropout 0.1 \
  --coef_resnet 1   
  
mse:0.46828359365463257, mae:0.4412410855293274



 
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_720 \
  --model 'iTransformer' \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --pred_len 720 \
  --e_layers 4 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 1024 \
  --d_ff 1024 \
  --itr 1 \
  --date_index  'HourOfDay'  \
  --learning_rate 0.001 \
  --trans_data True \
  --kernel_size 1 \
  --lradj type1 \
  --train_epochs 10 \
  --embed_dropout 0.1 \
  --coef_resnet 1   
  
mse:0.4687933027744293, mae:0.46562397480010986  
  
  
  
  
  
  
  