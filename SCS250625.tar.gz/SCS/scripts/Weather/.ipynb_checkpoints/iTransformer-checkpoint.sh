export CUDA_VISIBLE_DEVICES=1

model_name=iTransformer

python -u run.py \
  --is_training 1 \
  --root_path ./dataset/weather/ \
  --data_path weather.csv \
  --model_id weather_96_96 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --pred_len 96 \
  --e_layers 3 \
  --enc_in 21 \
  --dec_in 21 \
  --c_out 21 \
  --des 'Exp' \
  --d_model 1024\
  --d_ff 1024\
  --itr 1 \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.0001 \
  --lradj type3 \
  --embed_dropout 0.1 \
  --coef_resnet 1

mse:0.1628851294517517, mae:0.20714178681373596





python -u run.py \
  --is_training 1 \
  --root_path ./dataset/weather/ \
  --data_path weather.csv \
  --model_id weather_96_192 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --pred_len 192 \
  --e_layers 3 \
  --enc_in 21 \
  --dec_in 21 \
  --c_out 21 \
  --des 'Exp' \
  --d_model 1024\
  --d_ff 1024\
  --itr 1 \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.0001 \
  --lradj type3 \
  --embed_dropout 0.1 \
  --coef_resnet 1

mse:0.21007220447063446, mae:0.2504332661628723



  
  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/weather/ \
  --data_path weather.csv \
  --model_id weather_96_336 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --pred_len 336 \
  --e_layers 4 \
  --enc_in 21 \
  --dec_in 21 \
  --c_out 21 \
  --des 'Exp' \
  --d_model 1024\
  --d_ff 1024\
  --itr 1 \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.0001 \
  --lradj type3 \
  --embed_dropout 0.1 \
  --coef_resnet 1
  
mse:0.2724404036998749, mae:0.29635781049728394  
  

  

python -u run.py \
  --is_training 1 \
  --root_path ./dataset/weather/ \
  --data_path weather.csv \
  --model_id weather_96_720 \
  --model 'iTransformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --pred_len 720 \
  --e_layers 4 \
  --enc_in 21 \
  --dec_in 21 \
  --c_out 21 \
  --des 'Exp' \
  --d_model 512 \
  --d_ff 512\
  --itr 1 \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.0001 \
  --lradj type3 \
  --embed_dropout 0.1 \
  --coef_resnet 1  
  
mse:0.3507014214992523, mae:0.34789973497390747  
  
  
