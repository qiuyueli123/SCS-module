export CUDA_VISIBLE_DEVICES=7

model_name=Pyraformer

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/weather/ \
  --data_path weather.csv \
  --model_id weather_96_96 \
  --model 'Pyraformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 21 \
  --dec_in 21 \
  --c_out 21 \
  --des 'Exp' \
  --itr 1 \
  --d_model 1024 \
  --d_ff 1024 \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.00002 \
  --lradj type3

mse:0.15691763162612915, mae:0.20405828952789307





python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/weather/ \
  --data_path weather.csv \
  --model_id weather_96_192 \
  --model 'Pyraformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 21 \
  --dec_in 21 \
  --c_out 21 \
  --des 'Exp' \
  --itr 1 \
  --d_model 1024 \
  --d_ff 1024 \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.00002 \
  --lradj type3
  
mse:0.2118513584136963, mae:0.2525244653224945



python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/weather/ \
  --data_path weather.csv \
  --model_id weather_96_336 \
  --model 'Pyraformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 21 \
  --dec_in 21 \
  --c_out 21 \
  --des 'Exp' \
  --itr 1 \
  --d_model 1024 \
  --d_ff 1024 \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.00002 \
  --lradj type3
  
mse:0.27553340792655945, mae:0.2991330027580261




python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/weather/ \
  --data_path weather.csv \
  --model_id weather_96_720 \
  --model 'Pyraformer' \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 21 \
  --dec_in 21 \
  --c_out 21 \
  --des 'Exp' \
  --itr 1 \
  --d_model 1024 \
  --d_ff 1024 \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.00002 \
  --lradj type3
  
mse:0.3576747477054596, mae:0.35072654485702515

