python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/weather/ \
  --data_path weather.csv \
  --model_id weather_96_96 \
  --model PatchTST \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 21 \
  --dec_in 21 \
  --c_out 21 \
  --des 'Exp' \
  --itr 1 \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.0001 \
  --lradj type3 
mse:0.16932663321495 mae:0.213556721806526

 python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/weather/ \
  --data_path weather.csv \
  --model_id weather_96_192 \
  --model PatchTST \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 21 \
  --dec_in 21 \
  --c_out 21 \
  --des 'Exp' \
  --itr 1 \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.0001 \
  --lradj type3 
mse:0.210580646991729 mae:0.248671218752861

 python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/weather/ \
  --data_path weather.csv \
  --model_id weather_96_336 \
  --model PatchTST \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 21 \
  --dec_in 21 \
  --c_out 21 \
  --des 'Exp' \
  --itr 1 \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.0001 \
  --lradj type3   
mse:0.272363871335983 mae:0.293774753808975

 python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/weather/ \
  --data_path weather.csv \
  --model_id weather_96_720 \
  --model PatchTST \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 21 \
  --dec_in 21 \
  --c_out 21 \
  --des 'Exp' \
  --itr 1 \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --trans_data True \
  --kernel_size 3 \
  --learning_rate 0.0001 \
  --lradj type3  
mse:0.352095305919647 mae:0.345903187990188

