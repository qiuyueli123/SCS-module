export CUDA_VISIBLE_DEVICES=2

model_name=Autoformer

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_96 \
  --model 'Autoformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --d_model 32 \
  --d_ff 32 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --trans_data True \
  --kernel_size 1 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.3328940272331238, mae:0.37636542320251465  
  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_192 \
  --model 'Autoformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --d_model 32 \
  --d_ff 32 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --trans_data True \
  --kernel_size 1 \
  --lradj type3 \
  --train_epochs 10
  
mse:0.41905340552330017, mae:0.4325486123561859


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_336 \
  --model 'Autoformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --d_model 32 \
  --d_ff 32 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --trans_data True \
  --kernel_size 1 \
  --lradj type3 \
  --train_epochs 10
mse:0.45027297735214233, mae:0.4624656140804291


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_720 \
  --model 'Autoformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --d_model 32 \
  --d_ff 32 \
  --date_index 'HourOfDay' \
  --learning_rate 0.00002 \
  --trans_data True \
  --kernel_size 1 \
  --lradj type3 \
  --train_epochs 10

mse:0.45419660210609436, mae:0.47288358211517334


