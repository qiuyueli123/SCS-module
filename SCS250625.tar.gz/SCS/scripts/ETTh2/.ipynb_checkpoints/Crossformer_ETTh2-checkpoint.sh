export CUDA_VISIBLE_DEVICES=1

model_name=Crossformer   

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_96 \
  --model 'Crossformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --d_model 1024 \
  --d_ff 2048 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --trans_data True \
  --kernel_size 3 \
  --lradj type1 \
  --train_epochs 10
  
mse:0.3185001313686371, mae:0.3592981994152069  
  
  
  
  

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_192 \
  --model 'Crossformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --d_model 1024 \
  --d_ff 2048 \
  --date_index 'HourOfDay' \
  --learning_rate 0.00002 \
  --trans_data True \
  --kernel_size 3 \
  --lradj type1 \
  --train_epochs 10
  
mse:0.39710116386413574, mae:0.4099867045879364  
  


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_336 \
  --model 'Crossformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --d_model 1024 \
  --d_ff 2048 \
  --date_index 'HourOfDay' \
  --learning_rate 0.000075 \
  --trans_data True \
  --kernel_size 3 \
  --lradj type1 \
  --train_epochs 10
  
mse:0.43175697326660156, mae:0.437468022108078  

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_720 \
  --model 'Crossformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --d_model 1024 \
  --d_ff 2048 \
  --date_index 'HourOfDay' \
  --learning_rate 0.00005 \
  --trans_data True \
  --kernel_size 3 \
  --lradj type1 \
  --train_epochs 10
  
mse:0.44583559036254883, mae:0.4581244885921478