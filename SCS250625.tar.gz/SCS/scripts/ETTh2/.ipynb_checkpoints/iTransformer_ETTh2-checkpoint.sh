export CUDA_VISIBLE_DEVICES=1

model_name=iTransformer
  
  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_96 \
  --model 'iTransformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --pred_len 96 \
  --e_layers 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 3600 \
  --d_ff 3600 \
  --itr 1 \
  --date_index 'HourOfDay' \
  --learning_rate 0.001 \
  --trans_data True \
  --kernel_size 1 \
  --lradj type3 \
  --train_epochs 6 \
  --embed_dropout 0.3 \
  --coef_resnet 1
  
mse:0.28463006019592285, mae:0.3330761194229126  
  
  
  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_192 \
  --model 'iTransformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --pred_len 192 \
  --e_layers 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 4800 \
  --d_ff 4800 \
  --itr 1 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0002 \
  --trans_data True \
  --kernel_size 1 \
  --lradj type3 \
  --train_epochs 10 \
  --embed_dropout 0.3 \
  --coef_resnet 1
  
mse:0.3723180890083313, mae:0.38942772150039673  
  
  

  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_336 \
  --model 'iTransformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --pred_len 336 \
  --e_layers 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 4800 \
  --d_ff 4800 \
  --itr 1 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0002 \
  --trans_data True \
  --kernel_size 1 \
  --lradj type3 \
  --train_epochs 10 \
  --embed_dropout 0.3 \
  --coef_resnet 1  
  
mse:0.4215887784957886, mae:0.43795332312583923  
  
  

  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_720 \
  --model 'iTransformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --pred_len 720 \
  --e_layers 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 5400 \
  --d_ff 5400 \
  --itr 1 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0002 \
  --trans_data True \
  --kernel_size 1 \
  --lradj type3 \
  --train_epochs 5 \
  --embed_dropout 0.3 \
  --coef_resnet 1  
  
mse:0.3939960300922394, mae:0.4302690029144287  
  
  
  
  
  