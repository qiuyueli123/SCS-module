export CUDA_VISIBLE_DEVICES=2

model_name=Pyraformer

  

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_96 \
  --model 'Pyraformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --d_model 512 \
  --d_ff 512 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --trans_data True \
  --kernel_size 3 \
  --lradj type1 \
  --train_epochs 10
  
mse:0.3130270838737488, mae:0.3576068580150604  
  
  


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_192 \
  --model 'Pyraformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --d_model 512 \
  --d_ff 512 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --trans_data True \
  --kernel_size 3 \
  --lradj type1 \
  --train_epochs 10
mse:0.41680073738098145, mae:0.4199138879776001





python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_336 \
  --model 'Pyraformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --d_model 512 \
  --d_ff 512 \
  --date_index 'HourOfDay' \
  --learning_rate 0.00005 \
  --trans_data True \
  --kernel_size 3 \
  --lradj type1 \
  --train_epochs 10

mse:0.44348016381263733, mae:0.4416336417198181




python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_720 \
  --model 'Pyraformer' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1 \
  --trans_data True \
  --d_model 512 \
  --d_ff 512 \
  --date_index 'HourOfDay' \
  --learning_rate 0.00005 \
  --trans_data True \
  --kernel_size 3 \
  --lradj type1 \
  --train_epochs 10

mse:0.44569841027259827, mae:0.4578252136707306



