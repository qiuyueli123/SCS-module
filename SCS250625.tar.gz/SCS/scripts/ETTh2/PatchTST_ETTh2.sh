export CUDA_VISIBLE_DEVICES=1

model_name=PatchTST

  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_96 \
  --model 'PatchTST' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 3 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1  \
  --d_model 256 \
  --d_ff 256 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --trans_data True \
  --kernel_size 3 \
  --lradj type3 \
  --train_epochs 10 
  
mse:0.29110226035118103, mae:0.34421655535697937  


  
  

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_192 \
  --model 'PatchTST' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 4 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1  \
  --d_model 256 \
  --d_ff 256 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --trans_data True \
  --kernel_size 3 \
  --lradj type3 \
  --train_epochs 10 
mse:0.37126538157463074, mae:0.3966667652130127  


  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_336 \
  --model 'PatchTST' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 4 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1  \
  --d_model 256 \
  --d_ff 256 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0005 \
  --trans_data True \
  --kernel_size 3 \
  --lradj type1 \
  --train_epochs 10  
mse:0.40551185607910156, mae:0.42603811621665955  
  

  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_720 \
  --model 'PatchTST' \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 6 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --itr 1  \
  --d_model 512 \
  --d_ff 1024 \
  --date_index 'HourOfDay' \
  --learning_rate 0.0001 \
  --trans_data True \
  --kernel_size 3 \
  --lradj type3 \
  --train_epochs 4 \
  --patience 3
  
mse:0.4216005504131317, mae:0.4407435655593872  

  