export CUDA_VISIBLE_DEVICES=4

model_name=PatchTST

  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_96 \
  --model 'PatchTST' \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 256 \
  --d_ff 256 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.001 \
  --lradj type3 \
  --kernel_size 3   
  
mse:0.3085422217845917, mae:0.3559264838695526  
  
  



python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_192 \
  --model 'PatchTST' \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 256 \
  --d_ff 256 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.001 \
  --lradj type3 \
  --kernel_size 3 
  
mse:0.34755903482437134, mae:0.3801039755344391  



  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_336 \
  --model 'PatchTST' \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 256 \
  --d_ff 256 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.001 \
  --lradj type3 \
  --kernel_size 3   
  
mse:0.3858892321586609, mae:0.40977004170417786


  


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_720 \
  --model 'PatchTST' \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 256 \
  --d_ff 256 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.001 \
  --lradj type3 \
  --kernel_size 3   
 
mse:0.438021719455719, mae:0.4361734092235565

