export CUDA_VISIBLE_DEVICES=2

model_name=Crossformer

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_96 \
  --model 'Crossformer' \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 2048 \
  --d_ff 2048 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.00002 \
  --lradj type1 \
  --kernel_size 3 
  
mse:0.32226189970970154, mae:0.36012038588523865  
  


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_192 \
  --model 'Crossformer' \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 2048 \
  --d_ff 2048 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.00001 \
  --lradj type1 \
  --kernel_size 3 
mse:0.38204535841941833, mae:0.4054151177406311  


  
  

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_336 \
  --model 'Crossformer' \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 2048 \
  --d_ff 2048 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.000005 \
  --lradj type1 \
  --kernel_size 3 
mse:0.41162917017936707, mae:0.4174318313598633  
  
  

  
  
  
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_720 \
  --model 'Crossformer' \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 2048 \
  --d_ff 2048 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.000001 \
  --lradj type3 \
  --kernel_size 3  
  
 
mse:0.486131876707077, mae:0.46402883529663086
  
  