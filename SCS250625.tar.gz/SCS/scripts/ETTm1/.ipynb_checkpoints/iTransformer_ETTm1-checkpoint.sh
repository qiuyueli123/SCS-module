export CUDA_VISIBLE_DEVICES=2

model_name=iTransformer
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_96 \
  --model 'iTransformer' \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --pred_len 96 \
  --e_layers 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 64 \
  --d_ff 64 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.0002 \
  --lradj type3 \
  --kernel_size 3 \
  --embed_dropout 0.1 \
  --coef_resnet 1
  
mse:0.3150790333747864, mae:0.35903969407081604  
  
  
  
  
python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_192 \
  --model 'iTransformer' \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --pred_len 192 \
  --e_layers 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 64 \
  --d_ff 64 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.0002 \
  --kernel_size 3 \
  --embed_dropout 0.1 \
  --coef_resnet 1
  
 mse:0.3633722960948944, mae:0.3872551918029785 
  
 

python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_336 \
  --model 'iTransformer' \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --pred_len 336 \
  --e_layers 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 64 \
  --d_ff 64 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 10 \
  --patience 3 \
  --learning_rate 0.0002 \
  --lradj type3 \
  --kernel_size 3 \
  --embed_dropout 0.1 \
  --coef_resnet 1
  
mse:0.40065228939056396, mae:0.41053056716918945  
  



python -u run.py \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_720 \
  --model 'iTransformer' \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --pred_len 720 \
  --e_layers 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --des 'Exp' \
  --d_model 64 \
  --d_ff 64 \
  --itr 1 \
  --trans_data True \
  --date_index 'HourOfDay' \
  --train_epochs 4 \
  --patience 3 \
  --learning_rate 0.0002 \
  --lradj type3 \
  --kernel_size 3 \
  --embed_dropout 0.1 \
  --coef_resnet 1
  
mse:0.4656655192375183, mae:0.4457952082157135  
  
  
